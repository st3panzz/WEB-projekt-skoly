<?php
class Pages extends CI_Controller {
        public function index()
        {            
                $this->load->model('model_cetba');
                $data['polozky'] = $this->model_cetba->get_menu();

		$this->load->view('templates/header', $data);                
		$this->load->view('pages/tabulka', $data);  
		$this->load->view('templates/footer');   
	}   
        public function formular()
        {            
               $this->load->model('model_cetba');
                $data['polozky'] = $this->model_cetba->get_menu();
		$this->load->view('templates/headerlogout', $data);
		$this->load->view('pages/formular', $data);  
		$this->load->view('templates/footer');  
	}
        public function updateskol()
        {            
               $this->load->model('model_cetba');
                $data['polozky'] = $this->model_cetba->get_menu();
		$this->load->view('templates/headerlogout', $data);
		$this->load->view('pages/updateskol', $data);  
		$this->load->view('templates/footer');  
	}
        public function mapa()
        {
                $this->load->model('model_cetba');
                $data['polozky'] = $this->model_cetba->get_menu();
                
                $this->load->view('templates/header', $data);                
		$this->load->view('pages/mapa', $data);  
		$this->load->view('templates/footer');
        }
}