<?php
class Pages extends CI_Controller {
        public function index()
        {            
                $this->load->model('model_cetba');
                $data['polozky'] = $this->model_cetba->get_menu();

		$this->load->view('templates/header', $data);                
		$this->load->view('pages/tabulka', $data);  
		$this->load->view('templates/footer');   
	}   
        public function formular()
        {            
               $this->load->model('model_cetba');
                $data['polozky'] = $this->model_cetba->get_menu();
		$this->load->view('templates/headerlogout', $data);
		$this->load->view('pages/formular', $data);  
		$this->load->view('templates/footer');  
	}
         public function formularmajitele()
        {            
               $this->load->model('model_cetba');
                $data['polozky'] = $this->model_cetba->get_menu();
		$this->load->view('templates/headerlogout', $data);
		$this->load->view('pages/formularmajitele', $data);  
		$this->load->view('templates/footer');  
	}
        public function formularzamestnanci()
        {            
               $this->load->model('model_cetba');
                $data['polozky'] = $this->model_cetba->get_menu();
		$this->load->view('templates/headerlogout', $data);
		$this->load->view('pages/formularzamestnanci', $data);  
		$this->load->view('templates/footer');  
	}
        public function updatemajitelu()
        {            
               $this->load->model('model_cetba');
                $data['polozky'] = $this->model_cetba->get_menu();
		$this->load->view('templates/headerlogout', $data);
		$this->load->view('pages/updatemajitelu', $data);  
		$this->load->view('templates/footer');  
	}
        public function updatezamestnanci()
        {            
               $this->load->model('model_cetba');
                $data['polozky'] = $this->model_cetba->get_menu();
		$this->load->view('templates/headerlogout', $data);
		$this->load->view('pages/updatezamestnanci', $data);  
		$this->load->view('templates/footer');  
	}
        public function mapa()
        {
                $this->load->model('model_cetba');
                $data['polozky'] = $this->model_cetba->get_menu();
                
                $this->load->view('templates/header', $data);                
		$this->load->view('pages/mapa', $data);  
		$this->load->view('templates/footer');
        }
}