<html>
    <head>
    </head>
    <body>
<div><br>&nbsp</div>

<div class="container">
  <div class="vertical-center">
        <a href="<?php echo base_url("auth/formular");?>"><button type="submit" class="btn btn-outline-primary">Zaznamenání opravy</button></a>
  </div>
 <div><br>&nbsp</div>
  <div class="container" class="text-center">
<h1>Seznam oprav:</h1>
    <table class="table">
       <div class="row">
       <?php foreach ($oprava as $oprav) { ?>
          <div class="col">
         <div class="card" style="width: 15rem; height: 13rem;">
            <h5>Závada: <?= $oprav->zavada; ?></h5>
                <p>Datum opravy: <?= $oprav->datum; ?></p>
                <p>Vyměněné součástky: <?= $oprav->vymenene_soucastky; ?></p>
                <p>Čas opravy: <?= $oprav->cas; ?></p>
                <p>Náklady: <?= $oprav->naklady; ?></p>   
    </div>
        <p>&nbsp</p>
  </div>
    <?php } ?>
    </div>
    </table>
</div>
</div>
    </body>
</html>
