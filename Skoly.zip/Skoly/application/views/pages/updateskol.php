<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,'skoly');

if(isset($_POST['update']))
{
    $id = $_POST['id'];
    
    $query = "UPDATE skola SET skola='$_POST[skola]',mesto='$_POST[mesto]',pocet_prijatych='$_POST[pocet_prijatych]',obor='$_POST[obor]' where id='$_POST[id]' ";
    $query_run = mysqli_query($connection,$query);
    
    if($query_run)
    {
        echo "<p>Data byla upravena.</p>";
    }
    else
    {
        echo "<p>Data nebyla upravena!</p>";
    }
}
?>
<center>
    <div class="container">
        <div><br>&nbsp</div>
        <div class="vertical-center">
        <a href="<?php echo base_url('tabulka');?>"><button type="button" class="btn btn-outline-primary">Tabulka škol</button></a>
        <a href="<?php echo base_url('pages/formular');?>"><button type="button" class="btn btn-outline-primary">Přidání školy</button></a>
        </div>
    </div>
    <p>&nbsp</p>
    <h1 style="">Upravení dat o školách</h1>
    <form class="text-center" action="" method="POST">
<br><label for="id">ID:</label> <br><input type="text" name="id">
<br><label for="skola">Škola:</label> <br><input type="text" name="skola">
<br><label for="mesto">Město:</label><br><input type="text" name="mesto">
<br><label for="pocet_prijatych">Počet přijatých:</label><br><input type="text" name="pocet_prijatych">
<br><label for="obor">Obor:</label><br><input type="text" name="obor"><br>
<br><input type="submit" name="update" value="Odeslat">
    </form>
</center>
